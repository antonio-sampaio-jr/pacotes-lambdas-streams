package unidade2;
@Copyright(autor="Antonio Sampaio Jr",data="10/01/2017",versao="1.0")
public class InternetApp implements Internet {

	@Deprecated
	public void conectar() {}

	@Override
	public void conectarSSL() {
		// TODO Auto-generated method stub

	}

}
