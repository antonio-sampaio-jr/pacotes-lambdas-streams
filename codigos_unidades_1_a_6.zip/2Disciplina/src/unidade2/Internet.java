package unidade2;

public interface Internet {
	@Deprecated
	public void conectar();
	public void conectarSSL();
	
}
