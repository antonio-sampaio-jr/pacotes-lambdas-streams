package unidade2;

public @interface Copyright {
	String autor();
	String data();
	String versao();	
}
