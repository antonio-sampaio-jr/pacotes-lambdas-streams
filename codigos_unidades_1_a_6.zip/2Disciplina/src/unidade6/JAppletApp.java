package unidade6;

import javax.swing.JApplet;
import javax.swing.JOptionPane;

public class JAppletApp extends JApplet {

	@Override
	public void init() {
		JOptionPane.showMessageDialog(null, "Curso de Java");
	}
}
