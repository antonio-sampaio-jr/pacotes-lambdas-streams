package unidade6;

import javax.swing.JFrame;

public class ContentApp {

	public static void main(String[] args) {
		JFrame frame = new JFrame("Primeira Aplica��o");
		frame.setSize(350, 250);
		frame.setVisible(true);
	}

}
