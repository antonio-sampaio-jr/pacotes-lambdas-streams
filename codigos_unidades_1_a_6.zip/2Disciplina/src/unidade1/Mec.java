package unidade1;

import unidade1.br.abctreinamentos.Universidade;
import static unidade1.br.abctreinamentos.Universidade.*;


public class Mec {

	
	void avaliarEnsino()
	{
		Universidade ufpa = new Universidade();
	}
	
	public static void main(String[] args) {
		gerarRelatorioProfessoresMestresDoutores();
	}
}
