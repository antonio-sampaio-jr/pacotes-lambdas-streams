package unidade1;

public class DivisaoZeroException extends Exception {

}
