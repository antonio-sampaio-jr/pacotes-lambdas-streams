package unidade1.br.abctreinamentos.rh;

public class Professor extends Funcionario {

}
