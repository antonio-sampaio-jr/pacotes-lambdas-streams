package unidade1.br.abctreinamentos.rh;

public class Funcionario {

}
