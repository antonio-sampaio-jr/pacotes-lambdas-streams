package unidade1.br.abctreinamentos.rh;

public class Administrativo extends Funcionario {

}
