package unidade1.br.abctreinamentos.rh;

public class Diretor extends Funcionario {

}
