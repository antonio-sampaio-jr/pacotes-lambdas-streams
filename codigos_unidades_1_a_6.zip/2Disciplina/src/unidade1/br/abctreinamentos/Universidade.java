package unidade1.br.abctreinamentos;

public class Universidade {

	public static void gerarRelatorioProfessoresMestresDoutores()
	{
		
	}	
	
}
