/**
 * 
 */
package unidade3;

public class MinMaxApp<T> implements MinMax<T> {

	@Override
	public T min() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T max() {
		// TODO Auto-generated method stub
		return null;
	}

}
