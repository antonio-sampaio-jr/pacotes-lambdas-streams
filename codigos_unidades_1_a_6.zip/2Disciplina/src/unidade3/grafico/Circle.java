package unidade3.grafico;

public class Circle extends Shape {

}
