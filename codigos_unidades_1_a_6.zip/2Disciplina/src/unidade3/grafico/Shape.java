package unidade3.grafico;

public class Shape {

}
