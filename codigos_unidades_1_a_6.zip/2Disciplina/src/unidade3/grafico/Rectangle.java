package unidade3.grafico;

public class Rectangle extends Shape {

}
