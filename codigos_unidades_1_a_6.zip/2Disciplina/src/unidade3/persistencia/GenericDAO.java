package unidade3.persistencia;

public class GenericDAO<T> implements IDAO<T> {

	@Override
	public void create(T entidade) {}

	@Override
	public void read(T entidade) {}

	@Override
	public void update(T entidade) {}

	@Override
	public void delete(T entidade) {}

}
