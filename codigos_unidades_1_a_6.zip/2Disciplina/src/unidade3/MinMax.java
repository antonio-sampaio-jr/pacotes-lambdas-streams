package unidade3;

public interface MinMax<T> {

	T min();
	T max();
}
