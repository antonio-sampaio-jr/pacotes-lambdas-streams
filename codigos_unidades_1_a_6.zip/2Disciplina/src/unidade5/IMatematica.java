package unidade5;

public interface IMatematica {

	public int somar(int a, int b);
	public int subtrair(int a, int b);
	public int multiplicar(int a, int b);
	public int dividir(int a, int b);
	public double exponenciacao(double a, double b);
	public double radiciacao(double a, double b);
	
	
}
