package unidade5;
@FunctionalInterface
public interface IMath {
	double operacaco(double a, double b);
}
