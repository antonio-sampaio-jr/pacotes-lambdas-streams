module projetocClienteHTTP 
{
	requires projetoMensagensHTTP; 
}