package unidade6;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;

public class ConverterApp {

	private JFrame frame;
	private JTextField celsius;
	private JLabel lblNewLabel_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConverterApp window = new ConverterApp();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ConverterApp() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setTitle("Conversor Celsius");
		
		celsius = new JTextField();
		celsius.setBounds(53, 34, 130, 26);
		frame.getContentPane().add(celsius);
		celsius.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Celsius");
		lblNewLabel.setBounds(236, 39, 61, 16);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Converter");
	
		btnNewButton.addActionListener(ev-> {
				float cls = Float.parseFloat(celsius.getText());
				float fht = (float)(9.0/5.0)*(cls)+32;
				celsius.setText(fht + "");
		});
			
		btnNewButton.setBounds(54, 84, 117, 29);
		frame.getContentPane().add(btnNewButton);
		
		lblNewLabel_1 = new JLabel("32 Farenheit");
		lblNewLabel_1.setBounds(236, 89, 106, 16);
		frame.getContentPane().add(lblNewLabel_1);
	}
	
}
