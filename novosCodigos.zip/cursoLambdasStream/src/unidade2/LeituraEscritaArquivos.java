package unidade2;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class LeituraEscritaArquivos {

	public static void main(String[] args) {
		exemplo01();
	}
	
	//Novo método leitura em Arquivos
	public static void exemplo01()
	{
		try {
			String texto = Files.readString(Path.of("/Users/verenasampaio/Documents/cursoLambdas/cursoLambdasStream/src/unidade2/funcionarios.json"));
			System.out.println(texto);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	//Novo método escrita em Arquivos
	public static void exemplo02()
	{
		try {
			String novoFuncionario = """
					{
					"nome": "Pedro Ramos",
					"idade": 37,
					"cargo": "Engenheiro de Software",
					"departamento": "IT",
					"salario": 10000.00,
					"endereco": {
					  "rua": "Avenida Nazaré",
					  "numero": 33,
					  "cidade": "Belém",
					  "estado": "PA",
					  "cep": "66050-180"
					}
					"""; 
			Files.writeString(Path.of("/Users/verenasampaio/Documents/cursoLambdas/cursoLambdasStream/src/unidade2/funcionarios.json"),
					novoFuncionario,StandardOpenOption.APPEND);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
}
