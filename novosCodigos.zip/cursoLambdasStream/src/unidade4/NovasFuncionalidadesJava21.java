package unidade4;

import java.util.List;

public class NovasFuncionalidadesJava21 {

	public static void main(String[] args) {
		
		List<String> list = List.of("maçã", "banana", "uva");
		
		//Antes do Java 21
		var primeiroElemento = list.iterator().next();
		System.out.println(primeiroElemento);
		
		var ultimoElemento = list.get(list.size()-1);
		System.out.println(ultimoElemento);
		
		//Com o Java 21
		var primeiroElem = list.getFirst();
		System.out.println(primeiroElem);
		
		var ultimoElem = list.getLast();
		System.out.println(ultimoElem);
		
		System.out.println(list);
		
		System.out.println(list.reversed()); 
	}

}
