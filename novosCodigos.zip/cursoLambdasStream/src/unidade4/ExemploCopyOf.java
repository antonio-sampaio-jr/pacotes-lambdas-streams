package unidade4;

import java.util.*;

public class ExemploCopyOf {
    
	public static void main(String[] args) {
        // Criando uma lista original
        List<String> listaOriginal = new ArrayList<>();
        listaOriginal.add("Maçã");
        listaOriginal.add("Banana");
        listaOriginal.add("Laranja");

        // Criando uma cópia imutável da lista original
        List<String> listaImutavel = List.copyOf(listaOriginal);

        // Tentativa de adicionar um elemento à lista imutável
        // Isso resultará em uma exceção UnsupportedOperationException
        try {
        	listaOriginal.add("Pera");
        	//listaImutavel.add("Pera");
        } catch (UnsupportedOperationException e) {
            System.out.println("Não é possível modificar a lista imutável.");
        }

        // Imprimindo as listas
        System.out.println("Lista Original: " + listaOriginal);
        System.out.println("Lista Imutável: " + listaImutavel);
    }
}
