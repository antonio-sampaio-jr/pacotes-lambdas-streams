package unidade5;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MelhoriasStream {

	public static void main(String[] args) {
		exemplo04();
	}
	
	//Novo método takeWhile (espere um pouco)
	public static void exemplo01()
	{
		List<Integer> list   
        = Stream.of(1,2,3,4,5,6,7,8,9,10)  
                .takeWhile(i -> (i % 2 == 0)).collect(Collectors.toList());     
		System.out.println(list);  
	}
	
	//Novo método dropWhile (exclua enquanto)
	public static void exemplo02()
	{
		List<Integer> list   
		= Stream.of(2,2,3,4,5,6,7,8,9,10)  
            .dropWhile(i -> (i % 2 == 0)).collect(Collectors.toList());     
		System.out.println(list);  
	}	
	
	//Novo método ofNullable
	public static void exemplo03()
	{
		String nome = "Alice";
		Stream<String> stream = Stream.ofNullable(nome);
		stream.forEach(System.out::println);

		nome = null;
		stream = Stream.ofNullable(nome);
		stream.forEach(System.out::println);
	}	
	
	//Novo método iterate
	public static void exemplo04()
	{
		Stream.iterate(1, i -> i <= 10, i -> i*2)  
        .forEach(System.out::println);
	}
}
