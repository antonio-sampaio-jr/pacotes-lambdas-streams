package com.abctreinamentos.mensagens;

public class MensagensHTTP {

	public static String respostaOK()
	{
		return "HTTP 200";
	}
	
	public static String respostaNaoEncontrado()
	{
		return "HTTP 404";
	}
	
}
