package com.abctreinamentos.novasmensagens;

public class NovasMensagensHTTP {

	public static String respostaNAutorizado()
	{
		return "HTTP 401";
	}
	
	public static String respostaErro()
	{
		return "HTTP 500";
	}
	
}
