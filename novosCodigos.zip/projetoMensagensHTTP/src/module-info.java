module projetoMensagensHTTP 
{
	exports com.abctreinamentos.mensagens;
	exports com.abctreinamentos.novasmensagens;
}