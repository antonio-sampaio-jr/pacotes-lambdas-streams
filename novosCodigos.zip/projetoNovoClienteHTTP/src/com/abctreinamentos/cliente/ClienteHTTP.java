package com.abctreinamentos.cliente;

import com.abctreinamentos.mensagens.MensagensHTTP;
import com.abctreinamentos.novasmensagens.NovasMensagensHTTP;

public class ClienteHTTP {

	public static void main(String[] args) {
		String mensagemOK = MensagensHTTP.respostaOK();
		System.out.println(mensagemOK);
		
		String mensagemNOK = MensagensHTTP.respostaNaoEncontrado();
		System.out.println(mensagemNOK);
		
		String mensagemErro = NovasMensagensHTTP.respostaErro();
		System.out.println(mensagemErro);
	}

}
